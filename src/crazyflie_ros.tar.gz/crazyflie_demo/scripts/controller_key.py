#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from crazyflie_driver.srv import UpdateParams
from std_srvs.srv import Empty

class Controller():
    def __init__(self, use_controller, cmd_topic):
        rospy.wait_for_service('update_params')
        rospy.loginfo("found update_params service")
        self._update_params = rospy.ServiceProxy('update_params', UpdateParams)

        rospy.loginfo("waiting for emergency service")
        rospy.wait_for_service('emergency')
        rospy.loginfo("found emergency service")
        self._emergency = rospy.ServiceProxy('emergency', Empty)

        if use_controller:
            rospy.loginfo("waiting for land service")
            rospy.wait_for_service('land')
            rospy.loginfo("found land service")
            self._land = rospy.ServiceProxy('land', Empty)

            rospy.loginfo("waiting for takeoff service")
            rospy.wait_for_service('takeoff')
            rospy.loginfo("found takeoff service")
            self._takeoff = rospy.ServiceProxy('takeoff', Empty)
        else:
            self._land = None
            self._takeoff = None         

        # subscribe to the joystick at the end to make sure that all required
        # services were found
        rospy.Subscriber(cmd_topic, String, self._KeyChanged)
        self._takeoff()

    def _KeyChanged(self, data):
        if data == 's' and self._land != None:
            self._land()
        if data == 'q':
            self._emergency()
        if data == 'w' and self._takeoff != None:
            self._takeoff()

if __name__ == '__main__':
    rospy.init_node('crazyflie_demo_controller', anonymous=True)
    use_controller = rospy.get_param("~use_crazyflie_controller", False)
    cmd_topic = rospy.get_param("~cmd_topic", "command")
    controller = Controller(use_controller, cmd_topic)
    rospy.spin()
