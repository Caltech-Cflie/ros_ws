#!/usr/bin/env python

import rospy
import tf
from geometry_msgs.msg import PoseStamped
#from crazyflie_demo.msg import StateData



if __name__ == '__main__':
    rospy.init_node('init_pose', anonymous=True)
    worldFrame = rospy.get_param("~worldFrame", "/world")
    name = rospy.get_param("~name")
    r = rospy.get_param("~rate")
    x = rospy.get_param("~x")
    y = rospy.get_param("~y")
    z = rospy.get_param("~z")

    

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()