#!/usr/bin/env python

import rospy as rp
from std_msgs.msg import String
import sys, select, termios, tty

def getKey():
    settings = termios.tcgetattr(sys.stdin)
    tty.setraw(sys.stdin.fileno())
    rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
    if rlist:
        key = sys.stdin.read(1)
    else:
        key = ''

    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key

def command():
    pub = rp.Publisher('command',String, queue_size=1 )
    rp.init_node('Keyboard', anonymous=True)
    rate = rp.Rate(0.1)
    while not rp.is_shutdown():
        '''
        key = getKey()
        if key == '':
            pass
        elif key == 'w' or key == 's' or key == 'q':
            rp.loginfo('command: %s' %(key))
            pub.publish(key)
        else:
            pass    
        rate.sleep()
        '''
        rp.loginfo('command: %s' %('w'))
        pub.publish('w')
        rate.sleep()

if __name__ == "__main__":
    try: 
        command()
    except rp.ROSInternalException:
        pass
    