#!/usr/bin/env python

import rospy
import tf
from geometry_msgs.msg import PoseStamped, TransformStamped

class TargetPose():
    
    def __init__(self):
        rospy.init_node('publish_pose', anonymous=True)
        z = rospy.get_param("~z")
        self.name = rospy.get_param("~name")
        vicon = rospy.get_param("~vicon")
        self.rate = rospy.Rate(rospy.get_param("~rate"))
        worldFrame = rospy.get_param("~worldFrame", "/world")
        self.count = 0

        self.msg = PoseStamped()
        self.msg.header.seq = 0
        self.msg.header.stamp = rospy.Time.now()
        self.msg.header.frame_id = worldFrame
        self.msg.pose.position.x = 0
        self.msg.pose.position.y = 0
        self.msg.pose.position.z = z
        quaternion = tf.transformations.quaternion_from_euler(0, 0, 0)
        self.msg.pose.orientation.x = quaternion[0]
        self.msg.pose.orientation.y = quaternion[1]
        self.msg.pose.orientation.z = quaternion[2]
        self.msg.pose.orientation.w = quaternion[3]
        
        rospy.Subscriber(vicon, TransformStamped, self.set_initial)
    
    def set_initial(self, msg):
        self.count += 1
        #if self.count == 50:
            #self.msg.pose.position.x = msg.transform.translation.x
            #self.msg.pose.position.y = msg.transform.translation.y
            #self.msg.pose.position.z = msg.transform.translation.z            

            ##self.msg.pose.orientation.x = msg.transform.rotation.x
            #self.msg.pose.orientation.y = msg.transform.rotation.y
            #self.msg.pose.orientation.z = msg.transform.rotation.z
            #self.msg.pose.orientation.w = msg.transform.rotation.w
    
    def run(self):
        pub = rospy.Publisher("goal", PoseStamped, queue_size=1)
        while not rospy.is_shutdown():
            self.msg.header.seq += 1
            self.msg.header.stamp = rospy.Time.now()
            pub.publish(self.msg)
            self.rate.sleep()

    def test(self):
        self.rate = rospy.Rate(1)
        while not rospy.is_shutdown():
            info = "initial position: {:<5.3f} {:<5.3f} {:<5.3f} {:<5.3f} {:<5.3f} {:<5.3f} {:<5.3f}".format(
                                                                    self.msg.pose.position.x,
                                                                    self.msg.pose.position.y,
                                                                    self.msg.pose.position.z,
                                                                    self.msg.pose.orientation.x,
                                                                    self.msg.pose.orientation.y,
                                                                    self.msg.pose.orientation.z,
                                                                    self.msg.pose.orientation.w)
            rospy.loginfo(info)
            self.rate.sleep()
            
        

if __name__ == '__main__':
    pose = TargetPose()
    pose.run()
    #pose.test()
