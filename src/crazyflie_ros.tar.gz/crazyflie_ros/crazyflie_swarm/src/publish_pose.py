#!/usr/bin/env python

import rospy
import tf
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String 

class TargetPose():
    
    def __init__(self):
        self.trajectory = {'1': [0.0, 0.0],
                           '2': [0.0, 1.0],
                           '3': [1.0, 1.0],
                           '4': [1.0, 0.0]}

        rospy.init_node('publish_pose', anonymous=True)
        key_event = rospy.get_param("~key_topic")

        self.name = rospy.get_param("~goal_topic")
        self.rate = rospy.Rate(rospy.get_param("~rate"))
        worldFrame = rospy.get_param("~worldFrame", "/world")
        self.current_point = 1

        self.msg = PoseStamped()
        self.msg.header.seq = 0
        self.msg.header.stamp = rospy.Time.now()
        self.msg.header.frame_id = worldFrame
        self.msg.pose.position.x = self.trajectory['1'][0]
        self.msg.pose.position.y = self.trajectory['1'][1]
        self.msg.pose.position.z = 1.0
        quaternion = tf.transformations.quaternion_from_euler(0, 0, 0)
        self.msg.pose.orientation.x = quaternion[0]
        self.msg.pose.orientation.y = quaternion[1]
        self.msg.pose.orientation.z = quaternion[2]
        self.msg.pose.orientation.w = quaternion[3]
        
        rospy.Subscriber(key_event, String, self.to_next_point)
    
    def to_next_point(self, msg):
        if msg.data == ' ':
            self.current_point += 1
            if self.current_point == 5:
                self.current_point = 1

            self.msg.pose.position.x = self.trajectory[str(self.current_point)][0]
            self.msg.pose.position.y = self.trajectory[str(self.current_point)][1]
        
    
    def run(self):
        pub = rospy.Publisher("goal", PoseStamped, queue_size=1)
        while not rospy.is_shutdown():
            self.msg.header.seq += 1
            self.msg.header.stamp = rospy.Time.now()
            pub.publish(self.msg)
            self.rate.sleep()

    def test(self):
        self.rate = rospy.Rate(1)
        while not rospy.is_shutdown():
            info = "initial position: {:<5.3f} {:<5.3f} {:<5.3f} {:<5.3f} {:<5.3f} {:<5.3f} {:<5.3f}".format(
                                                                    self.msg.pose.position.x,
                                                                    self.msg.pose.position.y,
                                                                    self.msg.pose.position.z,
                                                                    self.msg.pose.orientation.x,
                                                                    self.msg.pose.orientation.y,
                                                                    self.msg.pose.orientation.z,
                                                                    self.msg.pose.orientation.w)
            rospy.loginfo(info)
            self.rate.sleep()
            
        

if __name__ == '__main__':
    pose = TargetPose()
    pose.run()
    #pose.test()
