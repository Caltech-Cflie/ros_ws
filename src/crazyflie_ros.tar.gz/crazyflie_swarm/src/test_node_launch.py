#!/usr/bin/env python
import rospy as rp
import roslaunch
import time as tm

package = 'crazyflie_swarm'
executable = 'test_node.py'

node = roslaunch.core.Node(package, executable, name="test_node")

launch = roslaunch.scriptapi.ROSLaunch()

context = roslaunch.loader.LoaderContext()
context.add_param("test_param", value=999)
launch.start()

process = launch.launch(node)
print process.is_alive
tm.sleep(5)
process.stop()
