#!/usr/bin/env python
import rospy as rp
from std_msgs.msg import String

class KeyboardPrint():
    
    def __init__(self):
        rp.init_node("keyboard_print", anonymous=True)
        topic = rp.get_param("~listen_to")

        self.sub = rp.Subscriber(topic, String, self.handle)

        rp.loginfo("Keyboard_print node initiated")


    def handle(self, msg):
        rp.loginfo("%s pressed event received!" %(msg))
        if msg.data == "k":
              rp.loginfo("%s acknoledged!" %(msg))     

if __name__ == "__main__":
    try: 
        key = KeyboardPrint()
        rp.spin()
    except rp.ROSInternalException:
        pass
    