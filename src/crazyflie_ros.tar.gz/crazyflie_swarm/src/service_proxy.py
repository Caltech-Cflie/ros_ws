#!/usr/bin/env python

import rospy
from std_msgs.msg import String
from crazyflie_driver.srv import UpdateParams
from std_srvs.srv import Empty

class Controller():
    def __init__(self, use_controller, key_topic):
        rospy.wait_for_service('update_params')
        self._update_params = rospy.ServiceProxy('update_params', UpdateParams)

        rospy.wait_for_service('emergency')
        self._emergency = rospy.ServiceProxy('emergency', Empty)

        if use_controller:
            rospy.wait_for_service('land')
            self._land = rospy.ServiceProxy('land', Empty)

            rospy.wait_for_service('takeoff')
            self._takeoff = rospy.ServiceProxy('takeoff', Empty)
            rospy.loginfo("Proxy Service active")
        else:
            self._land = None
            self._takeoff = None         
        # subscribe to the joystick at the end to make sure that all required
        # services were found
        rospy.Subscriber(key_topic, String, self._KeyChanged)

    def _KeyChanged(self, msg):
        if msg.data == 'l' and self._land != None:
            self._land()
        if msg.data == 'q':
            self._emergency()
        if msg.data == 'w' and self._takeoff != None:
            self._takeoff()

if __name__ == '__main__':
    rospy.init_node('Service_Proxy', anonymous=True)
    use_controller = rospy.get_param("~use_crazyflie_controller", False)
    key_topic = rospy.get_param("~key_topic")
    controller = Controller(use_controller, key_topic)
    rospy.spin()
