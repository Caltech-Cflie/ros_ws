#!/usr/bin/env python
import rospy as rp
from std_msgs.msg import String

if __name__ == "__main__":
    rp.init_node("test_node", anonymous=True)
    test_param = rp.get_param("test_param")
    pub = rp.Publisher('test_topic', String, queue_size=1)
    rate = rp.Rate(1)

    msg = String()
    msg.data = 'test_publish:' + str(test_param)
    while not rp.is_shutdown():
        pub.publish(msg)
        rate.sleep()