import rospy as rp
import roslaunch



if __name__ == "__main__":
    # pose_topics is a list of lists of two members
    # the first member is the topic name
    # the second member is the message type
    pose_topics = rp.get_published_topics(namespace='/vicon')

    # We don't need the marker topic, so remove it 
    for topic in pose_topics:
        if "vicon_bridge/Markers " in topic:
            pose_topics.remove(topic)

    for topic in pose_topics:
        # topic[0] contains the name of the topic, and
        # topic[0].split('/')[3] is the actual crazyflie's name
        # as displayed in the Vicon Tracker
        name = topic[0].split('/')[3]

        # This is the unique id of the crazyflie that determine 
        # its radio channel
        id = name.split('_')[1]
        
        controller_node = 



