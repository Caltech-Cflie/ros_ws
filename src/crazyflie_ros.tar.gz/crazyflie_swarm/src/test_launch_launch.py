#!/usr/bin/env python

import rospy as rp
import roslaunch as rl
import roslaunch.roslaunch_logs as rll
import time

if __name__ == "__main__":

    uuid = rl.rlutil.get_or_generate_uuid(None, False)
    rl.configure_logging(uuid)
    launch = rl.parent.ROSLaunchParent(uuid, ["/home/cflie/crazyflie_ws/src/crazyflie_ros/crazyflie_swarm/launch/test_keyboard.launch"], 
                                        roslaunch_strs=["<remap from='0' to='1'>"])

    launch.start()
    launch.spin()
