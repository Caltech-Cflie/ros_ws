#!/usr/bin/env python

import rospy
import tf
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String 

class TargetPose():
    
    def __init__(self):
        self.trajectory = {'1': [0.0, 0.0],
                           '2': [0.0, 1.0],
                           '3': [1.0, 1.0],
                           '4': [1.0, 0.0]}

        rospy.init_node('publish_pose', anonymous=True)
        key_event = rospy.get_param("~key_topic")

        self.name_3 = rospy.get_param("~goal_topic_3")
        self.name_2 = rospy.get_param("~goal_topic_2")
        self.rate = rospy.Rate(rospy.get_param("~rate"))
        worldFrame = rospy.get_param("~worldFrame", "/world")
        self.current_point = [1, 2]

        self.msg_2 = PoseStamped()
        self.msg_3 = PoseStamped()

        quaternion = tf.transformations.quaternion_from_euler(0, 0, 0)

        self.msg_2.header.seq = 0
        self.msg_2.header.stamp = rospy.Time.now()
        self.msg_2.header.frame_id = worldFrame
        self.msg_2.pose.position.x = self.trajectory['1'][0]
        self.msg_2.pose.position.y = self.trajectory['1'][1]
        self.msg_2.pose.position.z = 1.0
        self.msg_2.pose.orientation.x = quaternion[0]
        self.msg_2.pose.orientation.y = quaternion[1]
        self.msg_2.pose.orientation.z = quaternion[2]
        self.msg_2.pose.orientation.w = quaternion[3]


        self.msg_3.header.seq = 0

        self.msg_3.header.stamp = rospy.Time.now()
        self.msg_3.header.frame_id = worldFrame
        self.msg_3.pose.position.x = self.trajectory['2'][0]
        self.msg_3.pose.position.y = self.trajectory['2'][1]
        self.msg_3.pose.position.z = 1.0
        self.msg_3.pose.orientation.x = quaternion[0]
        self.msg_3.pose.orientation.y = quaternion[1]
        self.msg_3.pose.orientation.z = quaternion[2]
        self.msg_3.pose.orientation.w = quaternion[3]

        rospy.Subscriber(key_event, String, self.to_next_point)
    
    def to_next_point(self, msg):
        if msg.data == ' ':
            for position in self.current_point:
                position += 1
                if position == 5:
                    position = 1

            self.msg_2.pose.position.x = self.trajectory[str(self.current_point[0])][0]
            self.msg_2.pose.position.y = self.trajectory[str(self.current_point[0])][1]

            self.msg_3.pose.position.x = self.trajectory[str(self.current_point[1])][0]
            self.msg_3.pose.position.y = self.trajectory[str(self.current_point[1])][1]
        
    
    def run(self):
        pub_3 = rospy.Publisher(self.name_3, PoseStamped, queue_size=1)
        pub_2 = rospy.Publisher(self.name_2, PoseStamped, queue_size=1)
        while not rospy.is_shutdown():
            self.msg_3.header.seq += 1
            self.msg_2.header.seq += 1
            self.msg_3.header.stamp = rospy.Time.now()
            self.msg_2.header.stamp = rospy.Time.now()
            pub_2.publish(self.msg_2)
            pub_3.publish(self.msg_3)
            self.rate.sleep()
        

if __name__ == '__main__':
    pose = TargetPose()
    pose.run()
